# Blockcraft 1 Xbox One source port

This folder is the isolated Xbox One porting copy of Blockcraft 1. It preserves the existing LÖVE game and adds the first Xbox-specific source layer: exact controller bindings, analog dead zones, controller menu routing, LT flight press counting, D-pad hotbar selection, and controller action hooks.

## Current conversion state

This is converted Xbox-oriented source, not an installable Xbox package. The current Linux environment does not include Microsoft's Xbox GDK, Visual Studio Xbox components, an Xbox One development kit, or the authorized packaging tools needed to compile and deploy a retail Xbox package.

The remaining native conversion work is to implement the platform adapters for graphics, storage, audio, networking, HTTPS/account services, suspend/resume, and approved content/mod packaging. The existing Lua gameplay and server logic are preserved for that host conversion.

## Build handoff

Open this isolated project on the authorized Windows Xbox development machine, keep the controller layer and gameplay modules, and connect them to the selected GDK host/runtime. Do not overwrite the original Blockcraft project or production server while doing that integration.
